import os, time
from chrometings import stopDriver
from func_tj import getComarca, getProcesso, initialize
import varis

# TJ RS Collector
# OCR plus clicky clicker
# stopDriver()

os.system('cls' if os.name == 'nt' else 'clear')
start = time.time()
if not varis.comarcaList:
    initialize()

# with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
#     trolada = executor.map(getProcesso, varis.procList, varis.comarcaList)
#
#     for result in trolada:
#         varis.failList.append(''.join(result))

for i in range(len(varis.comarcaList)):
    getProcesso(varis.procList[i], varis.comarcaList[i])

varis.failList = list(filter(None,varis.failList))
varis.failList = list(dict.fromkeys(varis.failList))
print('Retrieval failures:', varis.failList)

varis.comarcaList = []
for i in varis.failList:
    getComarca(i)

varis.trollMark = varis.comarcaList
while len(varis.failList) > 0:
    for x in range(len(varis.failList)):
        try:
            getProcesso(varis.failList[x], varis.trollMark[x])
        except IndexError as e:
            pass

end = time.time()
chrono = round(end - start, 2)
stopDriver()
print("Tasks finished,", chrono, "seconds taken.")