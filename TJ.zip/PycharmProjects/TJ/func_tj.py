from chrometings import driver
from optics import ocr_remix
from selenium.common.exceptions import NoSuchElementException
import varis


def getComarca(proc):
    driver.switch_to.window(driver.window_handles[1])
    driver.find_element_by_xpath("//input[@type='text'][@name='num_processo_mask']").send_keys(proc)
    driver.find_element_by_xpath("//input[@type='radio'][@name='numCNJ'][@value='S']").click()
    checka = driver.find_element_by_name("id_comarca1").get_attribute("value")
    varis.comarcaList.append(''.join(checka))
    driver.find_element_by_xpath("//input[@type='text'][@name='num_processo_mask']").clear()
    return varis.comarcaList


def getProcesso(proc, comarca):
    driver.switch_to.window(driver.window_handles[0])
    numProc = proc.replace('.', '').replace('-', '')
    driver.implicitly_wait(30)
    driver.get(
        'https://www.tjrs.jus.br/site_php/consulta/consulta_processo.php?&versao=&versao_fonetica=2&tipo=1&id_comarca=' + comarca + '&intervalo_movimentacao=0&N1_var2=1&id_comarca1=' + comarca + '&num_processo_mask=' + numProc + '&num_processo=' + numProc + '&numCNJ=S')
    if len(driver.title) > 0:
        if len(driver.page_source) > 1500:  # Processo válido. Tentar pegar movimentacao
            try:
                driver.find_element_by_partial_link_text("Ver todas as mov").click()
            except NoSuchElementException:
                print(proc, 'se fudeu')
                pass
            if len(driver.title) > 0:  # Processo não é troll, dei o click e passou
                text = driver.find_element_by_xpath("//div[@id='conteudo']").text
                # print('DEBUG:', numProc)
                # print('DEBUG:', comarca)
                with open(str(varis.workDir + 'Movimentacoes/' + proc + '.txt'), "w") as o:
                    print(text, file=o)
                    print('Information saved as', proc + '.txt')
                with open(str(varis.workDir + 'cleared.txt'), "a") as p:
                    print(proc, file=p)
                try:
                    varis.trollMark.remove(comarca)
                    varis.failList.remove(proc)
                except ValueError:
                    pass
            else:  # Processo troll
                if proc not in varis.failList:
                    varis.failList.append(proc)
        else:  # Processo inválido, não vai ter movimentação
            with open(str(varis.workDir + 'Movimentacoes/' + proc + '.txt'), "w") as o:
                for row in driver.find_elements_by_css_selector("tr"):
                    cell = row.find_elements_by_tag_name("td")[0]
                    print(cell.text, file=o)
            print('Information saved as', proc + '.txt')
            with open(str(varis.workDir + 'cleared.txt'), "a") as p:
                print(proc, file=p)
            try:
                varis.trollMark.remove(comarca)
                varis.failList.remove(proc)
            except ValueError:
                pass
    else:  # Novo CAPTCHA necessário
        ocr_remix()
        driver.implicitly_wait(30)
        if len(driver.page_source) > 1500:
            try:
                driver.find_element_by_partial_link_text("Ver todas as mov").click()
            except NoSuchElementException:
                print('se fudeu')
                pass
            # element_present = EC.presence_of_element_located((By.XPATH, "//div[@id='conteudo']"))
            # WebDriverWait(driver, 10).until(element_present)
            # time.sleep(1)
            text = driver.find_element_by_xpath("//div[@id='conteudo']").text
            # print('DEBUG:', numProc)
            # print('DEBUG:', comarca)
            with open(str(varis.workDir + 'Movimentacoes/' + proc + '.txt'), "w") as o:
                print(text, file=o)
                print('Information saved as', proc + '.txt')
            with open(str(varis.workDir + 'cleared.txt'), "a") as p:
                print(proc, file=p)
        else:  # Pepega OK, mas processo invalido
            with open(str(varis.workDir + 'Movimentacoes/' + proc + '.txt'), "w") as o:
                for row in driver.find_elements_by_css_selector("tr"):
                    cell = row.find_elements_by_tag_name("td")[0]
                    print(cell.text, file=o)
            with open(str(varis.workDir + 'cleared.txt'), "a") as p:
                print(proc, file=p)
            print('Information saved as', proc + '.txt')
    return varis.failList


def initialize():
    x = 0
    with open(str(varis.workDir + 'procList.txt'), "r") as o:
        while x < 10:
            varis.procList.append(''.join(o.readline().split()))
            x += 1

    with open(str(varis.workDir + 'cleared.txt'), "r") as p:
        for i in p.readlines():
            varis.clearList.append(''.join(i.split()))
    varis.clearList = list(dict.fromkeys(varis.clearList))
    with open(str(varis.workDir + 'cleared.txt'), "w", encoding="utf-8") as p:
        for i in varis.clearList:
            print(i, file=p)

    print(varis.procList)
    print(varis.clearList)

    for i in varis.clearList:
        varis.procList.remove(i)

    initUrl = "https://www.tjrs.jus.br/site_php/consulta/consulta_processo.php?versao=&versao_fonetica=2&tipo=1&id_comarca=uruguaiana&intervalo_movimentacao=0&N1_var2=1&id_comarca1=uruguaiana&num_processo_mask=00022351320138210037&num_processo=00022351320138210037&numCNJ=S"
    driver.implicitly_wait(30)
    driver.get(initUrl)
    driver.switch_to.window(driver.window_handles[0])
    if len(driver.page_source) > 0:
        print('Site reached. Attempting to solve CAPTCHA.\n')
    # Image processing fuckery
    ocr_remix()
    driver.execute_script("window.open('https://www.tjrs.jus.br/site_php/consulta/index.php', '_blank')")
    # THIS HERE BE CATCHA LIST
    try:
        for i in varis.procList:
            getComarca(i)
    finally:
        pass