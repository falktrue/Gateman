from selenium import webdriver
import selenium, psutil, os, signal
from selenium.webdriver.chrome.options import Options
from contextlib import suppress
import varis
# Chrome tings
chrome_options = Options()
# chrome_options.add_argument("--headless")
chrome_options.add_argument("--remote-debugging-port=9222")
chrome_options.add_argument("--window-size=1280x720")
chrome_options.add_argument('log-level=3')
global driver

print(varis.workDir + 'chromedriver')
driver = webdriver.Chrome(options=chrome_options, executable_path=varis.workDir + 'chromedriver')

def stopDriver():
    pidList = []
    for process in psutil.process_iter():
        if process.name() == 'chrome' and '--test-type=webdriver' in process.cmdline():
            with suppress(psutil.NoSuchProcess):
                pidList.append(process.pid)
        if process.name() == 'chromedriver':
            with suppress(psutil.NoSuchProcess):
                pidList.append(process.pid)
    print('Stopping PIDs:', pidList)
    try:
        for i in pidList:
            os.kill(i, signal.SIGTERM)
        return 1
    except:
        return 0
