global comarcaList, procList, failList, trollMark
comarcaList, procList, failList, trollMark, clearList = ([] for i in range(5))
workDir = '/home/falk/PycharmProjects/TJ/'