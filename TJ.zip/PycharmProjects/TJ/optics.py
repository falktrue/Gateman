import cv2, easyocr
from chrometings import driver
import varis

def brt_cont(input_img, brightness = 0, contrast = 0):
    if brightness != 0:
        if brightness > 0:
            shadow = brightness
            highlight = 255
        else:
            shadow = 0
            highlight = 255 + brightness
        alpha_b = (highlight - shadow)/255
        gamma_b = shadow
        buf = cv2.addWeighted(input_img, alpha_b, input_img, 0, gamma_b)
    else:
        buf = input_img.copy()
    if contrast != 0:
        f = 131*(contrast + 127)/(127*(131-contrast))
        alpha_c = f
        gamma_c = 127*(1-f)
        buf = cv2.addWeighted(buf, alpha_c, buf, 0, gamma_c)
    return buf

def ocr_remix():
    troller = int(len(driver.title))
    while troller == 0:
        codeLyoko = driver.find_element_by_xpath("//img[@name='img_check']")
        codeLyoko.screenshot('test.png')
        img = cv2.imread("./test.png")
        img_not = brt_cont(img, -97, 120)
        # img_not = cv2.bitwise_not(img_not)
        # Do OCR and give me string
        reader = easyocr.Reader(['en'])
        result = reader.readtext(img_not, detail = 0, allowlist = '1234567890', mag_ratio = 0.7)
        try:
            resultatum = result[0]
            if len(resultatum) != 4:
                print("Invalid input length. Retrying.")
                resultatum = '9999'
            else:
                pass
        except IndexError:
            print("No characters detected. Retrying.")
            resultatum = '9999'
        driver.find_element_by_xpath("//input[@type='text']").send_keys(resultatum)
        driver.find_element_by_name("verifica").submit()
        troller = int(len(driver.title))
        if troller > 0:
            print("Human verification PASSED.")
        elif troller == 0:
            print("Incorrect code sent.")