from requests import Session
from bs4 import BeautifulSoup as bs
import os, ssl
procList = []
page_URL=("https://intranet.cgvadvogados.com.br/servicosintegracao/robostj/RobosTJ.asmx?op=RetornaProcessosPorUF")

# Disables warning for SSL certificate expiry
import urllib3
import requests
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

xmlRequest = """<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Header>
    <ValidationSoapHeader xmlns="http://cgvf.com.br/">
      <Token>bc1860680a1ad55c</Token>
    </ValidationSoapHeader>
  </soap12:Header>
  <soap12:Body>
    <RetornaProcessosPorUF xmlns="http://cgvf.com.br/">
      <uf>RS</uf>
    </RetornaProcessosPorUF>
  </soap12:Body>
</soap12:Envelope>"""

if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
    ssl._create_default_https_context = ssl._create_unverified_context

with Session() as s:
    headers = {'Content-Type': 'text/xml'} # set what your server accepts
    r = requests.post(page_URL, data=xmlRequest, headers=headers).text
    print("\nFetching completed.")

content = r
# Combine the lines in the list into a string
content = "".join(content)
bs_content = bs(content, "lxml")
result = bs_content.findAll('numero_processo')

# Treat every data from result
for i in result:      
    objetti = i.contents
    procList.append(str(''.join(objetti)).strip().replace(' ', ''))

# Cleanup bullshit empty values
procList = list(filter(None,procList))

print(len(procList), 'cases returned.')
procList = list(dict.fromkeys(procList))
print(len(procList), 'cases after removal of duplicates.')

with open('/home/falk/PycharmProjects/TJ/procList.txt', "w", encoding="utf-8") as o:
  for i in procList:
    print(i, file=o)